import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './DriverHome.css'; 
import io from 'socket.io-client';
import logo from '../assets/logo.jpg';

const DriverHome = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {
        const loggedUser = JSON.parse(localStorage.getItem('user'));
        if (loggedUser) {
            setUser(loggedUser);
            const socket = io('http://localhost:5000');
            socket.emit('join', loggedUser.id);

            socket.on('routeBooked', (notification) => {
                setNotifications((prevNotifications) => [...prevNotifications, notification]);
            });

            return () => socket.close();
        } else {
            navigate('/driver-login');
        }
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/driver-login');
    };

    if (!user) {
        return null; // or a loading indicator
    }

    const handlePostRoute = () => {
        navigate('/driver-route'); // Assuming there's a route for posting driver routes
    };

    return (
        <div className="driver-home">
            <header className="header">
                <div className="logo">
                    <img src={logo} alt="Logo" className="logo-image" />
                </div>
                <nav className="nav-links">
                    <a href="/">Home</a>
                    <a href="/about">About Us</a>
                    <a href="/contact">Contact</a>
                    <a href="/available-cabs">Available Cabs</a>
                    <button onClick={handleLogout} className="logout-button">Logout</button>
                </nav>
            </header>
            <main className="main-content">
                <h1>Driver Home</h1>
                <div className="welcome-box">
                    <h2>Welcome, {user.username}!</h2>
                    {user.profilePicture && (
                        <img
                            src={`data:image/jpeg;base64,${user.profilePicture}`}
                            alt="Profile"
                            className="profile-picture"
                        />
                    )}
                </div>
                <button onClick={handlePostRoute} className="post-route-button">
                    Post a Route
                </button>
                <div className="notifications">
                    <h2>Notifications</h2>
                    {notifications.map((notification, index) => (
                        <div key={index} className="notification-item">
                            <p>{notification.message}</p>
                        </div>
                    ))}
                </div>
            </main>
            <footer className="footer">
                <p>© RP 2024 ~ Developed By: T.R. Piyumi Probodani</p>
            </footer>
        </div>
    );
};

export default DriverHome;
